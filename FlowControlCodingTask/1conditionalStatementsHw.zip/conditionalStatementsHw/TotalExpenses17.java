package conditionalStatementsHw;

import java.util.Scanner;

public class TotalExpenses17 {
	public static void main(String[] args) {
		
	
		Scanner input = new Scanner(System.in);
		System.out.print("Enter the Quantity Purchased : ");
		int qty = input.nextInt();
		System.out.print("Enter the Amount Per Item : ");
		float amt = input.nextFloat();
		float exp;
		if (qty > 100) {
			exp = qty * amt;
			 
		} else {
			exp = qty * amt;
		}
		System.out.println("Total Expenses is : " + exp);
	}
}

//Enter the Quantity Purchased : 20
//Enter the Amount Per Item : 30
//Total Expenses is : 600.0
