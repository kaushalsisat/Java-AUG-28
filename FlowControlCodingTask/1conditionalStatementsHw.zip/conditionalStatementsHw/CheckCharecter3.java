package conditionalStatementsHw;

import java.util.Scanner;

//Write a program to check whether a character is alphabet or not


public class CheckCharecter3 {

	public static void main(String[] args) {
		 
		Scanner sc = new Scanner(System.in);
		     System.out.println("Enter the Character : ");
		     
		     char ch = sc.next().charAt(0);
		     
		  if(ch >= 'a' && ch <= 'z' || ch >= 'A' && ch <='z') {
			    System.out.println("This is Alphabet");
		  }else {
			  System.out.println("This is  Not a Alphabet");

		  }
		  
		       
	}
}
//Enter the Character : 
//2
//This is  Not a Alphabet
