package PatternTask;

public class Pattern22 {
	
	public static void main(String args[])
	{
		int r = 5;
		for (int m = 1; m <= r; m++) 
		{ 
			for (int n = r; n > m; n--)
			{
				System.out.print(" ");
			}
			int temp = 1;
			for (int p = 1; p <= m; p++)
			{
				System.out.print(temp + " ");
				temp = temp * (m - p) / (p);
			}
			System.out.println();
		}
	}
	
//    1 
//   1 1 
//  1 2 1 
// 1 3 3 1 
//1 4 6 4 1 


}
