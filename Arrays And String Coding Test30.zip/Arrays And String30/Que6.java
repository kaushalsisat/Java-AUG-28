package JavaTest30;

//9. Write a program in to find the sum of all elements of the array
import java.util.Scanner;
public class Que6 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enetr Limit of Array");
		    int l = sc.nextInt();
		    int sum =0;
		    int []a = new int[l];
		   
		    for(int i=0;i<l;i++)
			{
				System.out.printf("Element of a[%d] :",i);
				a[i]=sc.nextInt();
			} 
			for(int e:a)
			{
				sum = sum + e;
			}
			System.out.println("Sum of Array Elements : "+sum);
	    }
	}


