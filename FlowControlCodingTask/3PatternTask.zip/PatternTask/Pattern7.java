package PatternTask;

public class Pattern7 {
	
	public static void main(String args[])
	{
		int rows = 5;
		for (int m = 1; m <= rows; m++) 
                { 
                      for (int n = rows; n > m; n--)
			{
				System.out.print(" ");
			}
			for (int p = 1; p <= m; p++)
			{
				System.out.print(p + " ");
			}
			System.out.println();
		}
	}


}

//    1 
//   1 2 
//  1 2 3 
// 1 2 3 4 
//1 2 3 4 5 
