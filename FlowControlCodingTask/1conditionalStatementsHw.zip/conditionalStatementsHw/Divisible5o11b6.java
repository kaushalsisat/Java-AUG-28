package conditionalStatementsHw;

import java.util.Scanner;
//Write a program to check whether a number is divisible by 5 and 11 or not
public class Divisible5o11b6 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number");
		   int Num = sc.nextInt();
		   
		if(Num %5 == 0 || Num % 11 == 0) {  
			System.out.println("divisible by 5 and 11");
		}else {
			System.out.println("It is not divisible by 5 or 11");
		}
		   
	}
}
//Enter Any Number
//8
//It is not divisible by 5 or 11