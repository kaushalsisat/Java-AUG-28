package HospitalManagementSystem;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Genaral {
	public void List() {
	try {
		Thread.sleep(2000);//Thread
		System.out.println("THE LIST OF DOCTORS WE HAVE IS :");
		HashMap hm = new HashMap();
		hm.put(1, "NEUROGLIST");
		hm.put(2, "OPTHNOLOGIST");
		hm.put(3, "DENTIST");
		hm.put(4, "DERAMTIONLOGIST");
		hm.put(5, "CRDILOGIST");
		hm.put(6, "GENRALSURGON");
		hm.put(7, "ENT");
		Set a1 = hm.entrySet();
		Iterator i = a1.iterator();
		while(i.hasNext()) {
			Thread.sleep(1000);
			System.out.println(i.next());
			
		  }
		}catch(Exception e) {
			System.out.println("Just Check The Thread");
		}
		
	}
	
	synchronized void details() {
		String a = "Devasena";
		String b = "Kattapa";
		String c = "Bahubali";
		String d = "Ballalaldev";
		String e = "Keerti";
		String f = "Suresh";
		String g = "RajMohan";
				
	 System.out.println("Here is the list of doctors with their Destingtion:");
	 
	 try {
		 Thread.sleep(1000);
		 System.out.println("Neurologist :"+a);
		 Thread.sleep(1000);
		 System.out.println("Othomogist :"+b);
		 Thread.sleep(1000);
		 System.out.println("Dentist :"+c);
		 Thread.sleep(1000);
		 System.out.println("Deromotologist :"+d);
		 Thread.sleep(1000);
		 System.out.println("Cardologist :"+e);
		 Thread.sleep(1000);
		 System.out.println("Genral Surgeot :"+f);
		 Thread.sleep(1000);
		 System.out.println("ENT :"+g);
	 }
	 catch(Exception e1) {
		 System.out.println("CHECK WITH THE THREAD");
	 }
	 System.out.println("SELECT THE TYPE OF DOCTORS YOU WANT TO CONSALNTANT PROVIDE :");
	 
	                 Scanner sc1 = new Scanner(System.in);
	                 String c2 = sc1.nextLine();
	                 String c1 = c2.toUpperCase();
	 
	 if(c1.equals("NEUROGLIST")) {
		 System.out.println("YOUR APPOIMENT WITH" +" " +a+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else if(c1.equals("OPTHNOLOGIST")) {
		 System.out.println("YOUR APPOIMENT WITH" +" " +b+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else if(c1.equals("DENTIST")) {
		 System.out.println("YOUR APPOIMENT WITH" +" " +c+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else if(c1.equals("DERAMTIONLOGIST")) {
		 System.out.println("YOUR APPOIMENT WITH" +" " +d+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else if(c1.equals("CRDILOGIST")) {
		 System.out.println("YOUR APPOIMENT WITH" +" " +e+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else if(c1.equals("GENRALSURGON")) {
		 System.out.println("YOUR APPOIMENT WITH" +" " +f+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else if (c1.equals("ENT")){
		 System.out.println("YOUR APPOIMENT WITH" +" " +g+ " "+"Is ABOUT TO REDY...PLESE");
	 }
	 else {
	}
	 try {
		 Thread.sleep(2000);
		 System.out.println("THANK YOU FOR WATTING, YOUR APPOINTMENT IS REDY");
	 }catch(Exception e1) {
		 System.out.println("CHECK WITH THE THEAD");
	 }
	 
	}

   void check() {
	  //override
   }
}