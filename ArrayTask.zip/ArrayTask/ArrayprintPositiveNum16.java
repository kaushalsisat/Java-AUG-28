package ArrayTask;

import java.util.Scanner;

//Write a program to array elements print all Positive number

public class ArrayprintPositiveNum16 {
 
	public static void main(String[] args) {
		   
		Scanner sc = new Scanner(System.in);
		   System.out.print("Enter The Array Limit :");
		   int l = sc.nextInt();
		   int []a = new int[l];
		   
		 for(int i=0; i<l; i++)
		 {
			 System.out.printf("Element of Array is :",i);
			 a[i]=sc.nextInt();
		 }
		 System.out.println("Possitive Array Element");
		 for(int o:a) {
			 if(o>0)
			 System.out.println(o);
		 }
	}
}
//Enter The Array Limit :3
//Element of Array is :3
//Element of Array is :4
//Element of Array is :5
//Possitive Array Element
//3
//4
//5
