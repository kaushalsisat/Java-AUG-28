package conditionalStatementsHw;

import java.util.Scanner;

public class NumberNigativeOrPositive13 {

	public static void main(String[] args) {
		 
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter A Number");
		 int num = sc.nextInt();
		 
		 if(num > 0) {
			 System.out.println("It is Positive Number");
		 }
		 else if(num < 0)
			 System.out.println("It is Nigitive Number");
		 else {
			 System.out.println("This is Zero");
		 }
		 
	}
}
//Enter A Number
//12
//It is Positive Number



