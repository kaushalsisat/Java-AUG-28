package ArrayTask;

import java.util.Scanner;
//Write a program to array elements to print sum of Negative Numbers
public class ArrayPrintSumOfNigitivenum13 {
     public static void main(String[] args) 
     {
    	 Scanner sc = new Scanner(System.in); 
    	 System.out.println("Enter the limit of array");
    		int l = sc.nextInt();
    		int []a = new int[l];
            int sum =0;
        for(int i=0; i<l; i++){
        	System.out.println("This is a final Aary"+i);
             a[i]=sc.nextInt();
        }
       for(int o:a) 
       {
    	   if(o<0)
    		   sum = sum +o;
    	   
       }
       System.out.println("Sum of Negative Array Elements :" +sum);
    	 
     }
     
//     Enter the limit of array
//     2
//     This is a final Aary0
//     -2
//     This is a final Aary1
//     -2
//     Sum of Negative Array Elements :-4
}
