package StringTask;

public class ConcatString1 {
	public static void main(String[] args) {
		
	
	String FirstStr = "My Name Is";
	String SecStr = " Kaushal Sisat";
	String ThiStr =" ";
	
	ThiStr = FirstStr + SecStr;
	 
	System.out.println("Concat String Is: "+ ThiStr);
	
	
	}  

}

//Concat String Is: My Name Is Kaushal Sisat