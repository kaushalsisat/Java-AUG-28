package StringTask;

public class StringLength18 {

	public static void main(String[] args)
	{  
		String str = "Kaushal Sisat";
		int len = str.length();
		System.out.println("Given String : "+str);
		System.out.println("String Length : "+len);
	}

}

//Given String : Java Exercise
//String Length : 13