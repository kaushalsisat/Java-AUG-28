package ArrayTask;

import java.util.Scanner;

public class CubicArray3 {
	
       public static void main(String[] args) {
		   
    	   Scanner sc = new Scanner(System.in);
    	   System.out.println("Enter Limit Of Array : ");
    	   int l = sc.nextInt();
    	   int [] a = new int[l];
    	   for(int i=0; i<l; i++) {
    		   
    		   System.out.println("Element of a " +i);
    		   a[i]=sc.nextInt();
    	   }
    	   System.out.println("Cubic Array elements");
    	   for(int e:a) {
    		   System.out.println(e*e*e);
    	   }
	}
}

//Enter Limit Of Array : 
//2
//Element of a 0
//6
//Element of a 1
//8
//Cubic Array elements
//216
//512

