package loopingstatements;

import java.util.Scanner;

public class ReverseNumber13 {
	
	public static void main(String[] args) {
		 
	   Scanner sc = new Scanner(System.in);
	   System.out.println("Enter The Starting Number : ");
	   int start = sc.nextInt();
	   System.out.println("Enter the Ending Number : ");
	   int end = sc.nextInt();
	   while (start >= end) {
			System.out.println(start);
			start--;
		}

	   
	}

}

//Enter The Starting Number : 
//30
//Enter the Ending Number : 
//20
//30
//29
//28
//27
//26
//25
//24
//23
//22
//21
//20
