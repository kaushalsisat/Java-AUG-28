package StringTask;

public class CreateCharArray15 {
	

	public static void main(String[] args)
	{
		String str = "Java Exercises.";
		char[] a = str.toCharArray();
		System.out.println(a);
	}


}

//Java Exercises.