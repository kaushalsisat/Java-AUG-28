package StringTask;

public class IngnoreCase6 {

	public static void main(String[] args) {
		
		   String Name1 = "Kaushal Sisat";
		   String Name2 = "Kaushal Sisat";
		   
		   System.out.println("String 1: " +Name1);
		   System.out.println("String 2: " +Name2);
		   
		   int Com = Name1.compareToIgnoreCase(Name2);
		   
		   if(Com < 0 ){
			 System.out.println("String One Is Less Than String Two");  
		   }else if(Com == 0) {
			   System.out.println("String One And String Two Is Equal");
		   }else {
			   System.out.println("String one Is Greater Than String Two");
		   }
			   
	}
}

//String 1: Kaushal Sisat
//String 2: Kaushal sisat
//String One And String Two Is Equal
