package StringTask;

public class ReplaceSubstring20 {

	public static void main(String[] args)
	{
		String str1 = "String and String Function";
		
		//Replace to String
		String str2 = str1.replaceAll("String", "Java");
		System.out.println("Given String : " + str1);
		System.out.println("After String Replace : " + str2);
	}
}

//Given String : String and String Function
//After String Replace : Java and Java Function