package IBMWiproArrayTask;

public class AddMatrix1 {
  
	   public static void main(String[] args) {
		
		// creating two matrices
          int a[][] = {{1,2,3},{2,3,4},{3,4,3}};
          int b[][] = {{1,2,3},{2,3,4},{3,4,3}};
		// creating another matrix to store the sum of two matrices
			
           int c[][] = new int[3] [3];
			 
           
           for(int i=0; i<3; i++) {
        	   for(int j=0; j<3; j++) {
        	  c[i][j] = a[i][j] + b[i][j];
        	  System.out.print(c[i][j] + " ");
        	   }
        	  System.out.println();
           }
	  }
}

//2 4 6 
//4 6 8 
//6 8 6 


