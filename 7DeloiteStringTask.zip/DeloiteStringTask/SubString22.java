package StringTask;

public class SubString22 {
	
	public static void main(String[] args)
	{
		String str = "Kaushal sisat is a Most Popular Person";
		String new_str = str.substring(19,31);
		System.out.println("Given String : " + str);
		System.out.println("SubString of a given String : " +new_str);
	}


}
 
//Given String : Kaushal sisat is a Most Popular Person
//SubString of a given String : Most Popular