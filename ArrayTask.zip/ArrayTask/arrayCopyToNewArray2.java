package ArrayTask;

import java.util.Scanner;
public class arrayCopyToNewArray2 {
	
	public static void main(String[] args)
	{   
		Scanner input =new Scanner(System.in);
		System.out.print("Enter the Array Limit :");
		int l =input.nextInt();
		int [] a =new int[l];
		int [] c =new int[l];
		int sum = 0;
		for(int i=0;i<l;i++)
		{
			System.out.printf("Element of a[%d] :",i);
			a[i]=input.nextInt();
		}
		for(int i=0;i<l;i++)
		{
			c[i] = a[i];
		}
		System.out.print("\nOriginal Array Elements...");	
		for(int i=0;i<l;i++)
		{
			System.out.printf("\na[%d] = %d",i,a[i]);
		}
		System.out.print("\n\nCopy Array Elements one to Another Array...");	
		for(int i=0;i<l;i++)
		{
			System.out.printf("\nc[%d] = %d",i,c[i]);
		}
    }

}

//Enter the Array Limit :5
//Element of a[0] :1
//Element of a[1] :2
//Element of a[2] :3
//Element of a[3] :4
//Element of a[4] :5
//
//Original Array Elements...
//a[0] = 1
//a[1] = 2
//a[2] = 3
//a[3] = 4
//a[4] = 5
//
//Copy Array Elements one to Another Array...
//c[0] = 1
//c[1] = 2
//c[2] = 3
//c[3] = 4
//c[4] = 5
