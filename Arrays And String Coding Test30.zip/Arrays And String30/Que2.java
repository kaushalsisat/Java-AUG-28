package JavaTest30;

//Write a program to array elements print all Even number

import java.util.Scanner;

public class Que2 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enetr Limit of Array");
		    int l = sc.nextInt();
		    int []a = new int[l];
		  
		for(int i=0; i<l; i++) {
			System.out.printf("Elements Of Array is : ",i);
		  a[i]=sc.nextInt();
		}
		System.out.println("Convert in Even Array Elements");
	    for(int o:a) {
	    	if(o%2==0) {
	    		System.out.println("Even Array Elements is"+o);
	    	}
	    }
	}
}
