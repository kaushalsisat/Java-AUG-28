package ArrayTask;

import java.util.Scanner;

public class ArraySumOfEle20 {

	public static void main(String[] args)
	{   
		Scanner input =new Scanner(System.in);
		System.out.print("Enter the Array Limit :");
		int l =input.nextInt();
		int [] a =new int[l]; 
		int sum = 0; 
		for(int i=0;i<l;i++)
		{
			System.out.printf("Element of a[%d] :",i);
			a[i]=input.nextInt();
		} 
		for(int e:a)
		{
			sum = sum + e;
		}
		System.out.println("Sum of Array Elements : "+sum);
    }
//	Enter the Array Limit :2
//	Element of a[0] :2
//	Element of a[1] :3
//	Sum of Array Elements : 5

}
