package StringTask;

public class RemoveWhiteSpace23 {
	

	public static void main(String[] args)
	{
		String str = "	     JavaProgrammer	       ";
		String newStr = str.trim();
		System.out.println("Given String :" + str);
		System.out.println("After Trim White Space in String : " + newStr);
	}

}

//Given String :	     JavaProgrammer	       
//After Trim White Space in String : JavaProgrammer