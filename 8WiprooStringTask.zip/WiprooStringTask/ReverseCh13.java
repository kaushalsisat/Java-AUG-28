package WiprooStringTask;

public class ReverseCh13 {
	
	public static void main(String[] args) {    
        String string = "Sisat Kaushal pralhadrao";    
        //Stores the reverse of given string    
        String reversedStr = "";    
            
        //Iterate through the string from last and add each character to variable reversedStr    
        for(int i = string.length()-1; i >= 0; i--){    
            reversedStr = reversedStr + string.charAt(i);    
        }    
            
        System.out.println("Original string: " + string);    
        //Displays the reverse of given string    
        System.out.println("Reverse of given string: " + reversedStr);    
    }   

}

//Original string: Sisat Kaushal pralhadrao
//Reverse of given string: oardahlarp lahsuaK tasiS
