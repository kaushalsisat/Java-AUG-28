package JavaTest30;

import java.util.Scanner;
//3. Write a program to array elements print all Odd number
public class Que3 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enetr Limit of Array");
		    int l = sc.nextInt();
		    int []a = new int[l];
		  
		for(int i=0; i<l; i++) {
			System.out.printf("Elements Of Array is : ",i);
		  a[i]=sc.nextInt();
		}
		System.out.println("Convert in Odd Array Element");
	    for(int o:a) {
	    	if(o%2==1) {
	    		System.out.println("Odd Array Elements is : "+o);
	    	}
	    }
	}
}
