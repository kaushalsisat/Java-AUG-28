package ArrayTask;

import java.util.Scanner;

public class PrintNigativeNum17 {


	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		   System.out.print("Enter The Array Limit :");
		   int l = sc.nextInt();
		   int []a = new int[l];//Array
		   
		 for(int i=0; i<l; i++)
		 {
			 System.out.printf("Element of Array is :",i);
			 a[i]=sc.nextInt();
		 }
		 System.out.println("Negative Array Elements");
		 for(int o:a) {
			 if(o<0)
			 System.out.println(o);
		 }
	}
}

//Enter The Array Limit :3
//Element of Array is :2
//Element of Array is :-4
//Element of Array is :-3
//Negative Array Elements
//-4
//-3

