package IBMWiproArrayTask;

public class PrintSum13 {

	public static void main(String[] args) {
		 //array
		int sum=0;
		int arr[] = new int[] {2,3,4,5,6};
		for(int i=0; i<arr.length; i++) {
		     sum = sum +arr[i];
		  
		}
		System.out.println("Sum of All The Elements is: "+sum);
	}
}

//Sum of All The Elements is: 20