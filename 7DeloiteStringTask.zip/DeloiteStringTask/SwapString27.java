package StringTask;

public class SwapString27 {
	
	public static void main(String args[])
	{
		String str1 = "Computer";
		String str2 = "Science";
		String t_str;
		System.out.println("Before Swap String 1 :"+str1);
		System.out.println("Before Swap String 2 :"+str2);
		t_str = str1;
		str1 = str2;
		str2 = t_str;
		System.out.println("After Swap String 1 :"+str1);
		System.out.println("After Swap String 2 :"+str2);
	}


}
//Before Swap String 1 :Computer
//Before Swap String 2 :Science
//After Swap String 1 :Science
//After Swap String 2 :Computer