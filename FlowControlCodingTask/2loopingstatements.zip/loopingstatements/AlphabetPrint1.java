package loopingstatements;

////Write a program to print all alphabets from a to z

public class AlphabetPrint1 {
         public static void main(String[] args) {
        	 
        	 char Alphbet;
        for(Alphbet = 'a'; Alphbet <= 'z'; Alphbet++ ) {
        	System.out.println("Alphbet Print a to z :---- " + Alphbet);
        }
	
      }
	
}


//Alphbet Print a to z :---- a
//Alphbet Print a to z :---- b
//Alphbet Print a to z :---- c
//Alphbet Print a to z :---- d
//Alphbet Print a to z :---- e
//Alphbet Print a to z :---- f
//Alphbet Print a to z :---- g
//Alphbet Print a to z :---- h
//Alphbet Print a to z :---- i
//Alphbet Print a to z :---- j
//Alphbet Print a to z :---- k
//Alphbet Print a to z :---- l
//Alphbet Print a to z :---- m
//Alphbet Print a to z :---- n
//Alphbet Print a to z :---- o
//Alphbet Print a to z :---- p
//Alphbet Print a to z :---- q
//Alphbet Print a to z :---- r
//Alphbet Print a to z :---- s
//Alphbet Print a to z :---- t
//Alphbet Print a to z :---- u
//Alphbet Print a to z :---- v
//Alphbet Print a to z :---- w
//Alphbet Print a to z :---- x
//Alphbet Print a to z :---- y
//Alphbet Print a to z :---- z