package ArrayTask;

import java.util.Scanner;

public class ArrayReverseOrder7 {

	 public static void main(String[] args) {
		   Scanner sc = new Scanner(System.in);
		   System.out.print("Enter the Array Limit :");
		   int l =sc.nextInt();
		   int [] a = new int[l];
		   for(int i=0; i<l; i++) {
			   System.out.printf("Element of a",i);
			   a[i]= sc.nextInt();
		   }
		 System.out.println("Disply Reverse Order in Array");
	  for(int i=l-1; i>=0; i--) {
		  System.out.println(a[i]);
	  }
	}
}


//Enter the Array Limit :3
//Element of a4
//Element of a5
//Element of a6
//Disply Reverse Order in Array
//6
//5
//4
