package ArrayTask;

import java.util.Scanner;

public class ArrayPrintEvenNu4 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a Limit of Array");
	     int l = sc.nextInt();
	     int[]a = new int[l];
	   
	     for(int i=0; i<l; i++) {
	    	 System.out.println("user Array"+ i);
	    	  a[i]=sc.nextInt();
	     }
	    System.out.println("Convert in Even Array");     
	    
	    for(int o:a) {
	    	if(o%2==0) {
	    	System.out.println("Convert in"+" "+o);	
	    	}
	    }
	}
}

//Enter a Limit of Array
//4
//user Array0
//2
//user Array1
//3
//user Array2
//4
//user Array3
//5
//Convert in Even Array
//Convert in 2
//Convert in 4



