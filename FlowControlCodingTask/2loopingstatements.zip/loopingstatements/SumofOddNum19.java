package loopingstatements;

import java.util.Scanner;

//Write a program to find sum of all odd numbers between 1 to n

public class SumofOddNum19 {
	
	public static void main(String[] args)
	{
		Scanner input = new Scanner(System.in);
		System.out.print("Enter The Number of Limit : ");
		int l =input.nextInt();
		int sum = 0;
		for(int s=1;s<=l;s++)
		{
			if(s%2==1)
				sum = sum + s;
 
		}
		System.out.println("Sum of Odd Numbers :"+sum);
	}

}

//Enter The Number of Limit : 30
//Sum of Odd Numbers :225
