package ArrayTask;

import java.util.Scanner;
//Write a program to array elements to print sum of Even Numbers

public class ArraySumofEvenNu12 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		   System.out.println("Enter The Limit of Array");   
		   int l =sc.nextInt();
		   int []a = new int[l];
		   int sum =0;
	for(int i=0; i<l; i++)
	{
		System.out.printf("Element of a",i);
		a[i]=sc.nextInt();
	}
	for(int e:a) 
	{
		if(e%2==0)
			 sum = sum +e;
	}
	System.out.println("Sum Of Array Element:"+sum);
  }
	 

}

//Enter The Limit of Array
//2
//Element of a3
//Element of a4
//Sum Of Array Element:4
