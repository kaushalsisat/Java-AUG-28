package conditionalStatementsHw;

import java.util.Scanner;
//Write a program to input any character and check whether it is alphabet, digit or special character

public class AlphaNumDigi2 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		     System.out.println("Enter a values :");
		     
		     char ch = sc.next().charAt(0);
		     if(ch >= 'a' && ch <= 'z' || ch >= 'A' && ch >= 'Z') {
		    	 System.out.println("This is a Alphabet");
		     } else if(ch >= '0' && ch <= '9') {
		    	 System.out.println("This is a Number");
		     }else {
		    	 System.out.println("This is a Special Character");
		     }
	}

}

//Enter a values :
//&
//This is a Special Character


