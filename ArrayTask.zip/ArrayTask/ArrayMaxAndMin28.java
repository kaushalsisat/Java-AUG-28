package ArrayTask;

import java.util.Scanner;


public class ArrayMaxAndMin28 {
     
	public static void main(String[] args) {
		
		Scanner input =new Scanner(System.in);
		System.out.print("Enter the Array Limit :");
		int l =input.nextInt();
		int [] a =new int[l];
		int max=0,min=0;
		for(int i=0;i<l;i++)
		{
			System.out.printf("Element of a[%d] :",i);
			a[i]=input.nextInt();
		}		
		max=a[0];//max
		min=a[0];//min
		for(int i=0;i<l;i++)
		{
			if(max<a[i])
				max=a[i];
			if(min>a[i])
				min=a[i];
		}
		System.out.println("Maximum Element of Array : "+max);
		System.out.println("Minimum Element of Array : "+min);

		    
	}
}


//Enter the Array Limit :3
//Element of a[0] :3
//Element of a[1] :4
//Element of a[2] :5
//Maximum Element of Array : 5
//Minimum Element of Array : 3



