package HotelMAnagement25_9;

public class DeluxeRoom extends Room{

	private double roomSize;
	
	public DeluxeRoom(String roomId, int roomNum, double roomFare, double roomSize){
	   super(roomId, roomNum, roomFare);
	   this.roomSize = roomSize;
	}   
	   @Override
	    void roomInfo() {
	    	System.out.println("Deluxe Room Info :");
			  System.out.println("Room Id        :" +super.getRoomId());
			  System.out.println("Room Number    :" +super.getRoomNum());
			  System.out.println("Room Fare      :" +super.getRoomFare());
			  System.out.println("Room Size      :" +this.roomSize);
			  System.out.println();
	    }
}

