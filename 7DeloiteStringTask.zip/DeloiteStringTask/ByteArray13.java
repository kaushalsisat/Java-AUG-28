package StringTask;

public class ByteArray13 {
	public static void main(String[] args)
	{
		String str1 = "This is a sample String.";
		byte[] bytearr = str1.getBytes();
		String str2 = new String(bytearr);
		System.out.println("The new String equals " +str2);
	}


}

//The new String equals This is a sample String.
