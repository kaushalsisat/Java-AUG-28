package IBMWiproArrayTask;

public class PrintOddNu9 {
	
	public static void main(String[] args) {

		// Initialize array
		int[] arr = new int[] { 1, 2, 3, 4, 5 };

		System.out.println("Elements of given array present on Odd position: ");
 
		for (int i = 1; i < arr.length; i++) {
			
			if(i%2==1)
			System.out.println("Odd Number is: " +i);
		}
	}

}
//Elements of given array present on Odd position: 
//Odd Number is: 1
//Odd Number is: 3
