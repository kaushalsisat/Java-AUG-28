package StringTask;

public class CompairString5 {

	public static void main(String[] args) {
		
		String str1= "Kaushal Sisat";
		String str2= "Kaushal Sisat1";
		
		System.out.println("String1: "+str1);
		System.out.println("String2: "+str2);
		
		int com =str1.compareTo(str2);
		if(com < 0) {
			System.out.println("String One Is Less Than String Two");
		}else if(com == 0) {
			System.out.println("String One And String Two is Equal");
		}else{
			System.out.println("String One is Greater Than String Two");
		}
		
	}
}

//String1: Kaushal Sisat
//String2: Kaushal Sisat1
//String One Is Less Than String Two
