package Task1;

import java.util.Scanner;

public class Task1 {
	//find area of circle
     
	public static void main(String[] args) {
		
		      int radius;
		      double area;
		      Double PI;

	Scanner sc = new Scanner(System.in);	
	 System.out.println("enter Radius of Circle");
	    radius = sc.nextInt();
	 System.out.println("Enter A VAlue of PI");   
	    PI = sc.nextDouble();
	    area = (radius*radius)*PI;
	    System.out.println("Area of the circle is ::"+area);	     
	}
}

//enter Radius of Circle
//10
//Enter A VAlue of PI
//3.14
//Area of the circle is ::314.0
