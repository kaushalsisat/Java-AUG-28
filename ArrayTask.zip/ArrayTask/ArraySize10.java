package ArrayTask;

import java.util.Scanner;

//Write a program in to array size to be user input print it


public class ArraySize10 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enter The Limit Of Array");
		     int l = sc.nextInt();
		     int [] a = new int[l];
		     for(int i=0; i<l; i++)
				{
					System.out.printf("Element of a[%d] :",i);
					a[i]=sc.nextInt();
				}
		     System.out.println("Display Array Element");
		  for(int e:a) {
			    System.out.println("Size of Array is "+e);
		  }
	}
}

//Enter The Limit Of Array
//2
//Element of a[0] :1
//Element of a[1] :2
//Display Array Element
//Size of Array is1
//Size of Array is2
