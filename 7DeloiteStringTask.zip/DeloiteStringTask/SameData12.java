package StringTask;

public class SameData12 {

	public static void main(String[] args)
	{
        String s1 = "Kaushal Sisat";
        String s2 = "Sisat Kaushal";
        String s3 = "Kaushal Sisat";
		 
        boolean equ1 = s1.equals(s2);
        boolean equ2 = s1.equals(s3);
		System.out.println("'" + s1 + "' equals '" +s2 + "' ? " + equ1);
		System.out.println("'" + s1 + "' equals '" +s3 + "' ? " + equ2);
	}

}

//'Kaushal Sisat' equals 'Sisat Kaushal' ? false
//'Kaushal Sisat' equals 'Kaushal Sisat' ? true