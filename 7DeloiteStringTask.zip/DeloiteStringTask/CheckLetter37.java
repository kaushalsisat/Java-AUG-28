package StringTask;

public class CheckLetter37 {

	public static void main(String[] args)
	{
		String str = "String Exercises";
		boolean pre = false;
		for(int i = 0;i<str.length();i++)
		{
			if(str.charAt(i) == 'x')
			{
				pre=true;
				break;
			}
		}
		System.out.println(pre);
	}

}

//true