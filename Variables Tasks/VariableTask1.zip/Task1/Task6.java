package Task1;

import java.util.Scanner;

public class Task6 {
   
	public static void main(String[] args) {
		  
		  Scanner sc = new Scanner(System.in);
		      
		  System.out.println(" Enter The Quantity ");
		  int Quantity = sc.nextInt();
		  
		  System.out.println(" Enter The Price of One Object");
		  Double Price =  sc.nextDouble();
		 
		  Double TotalQuantityVal = Quantity * Price;
		  
		System.out.println(" Value Of Total Quantity is : " + TotalQuantityVal);
	}
}
//Enter The Quantity 
//20
//Enter The Price of One Object
//20
//Value Of Total Quantity is : 400.0