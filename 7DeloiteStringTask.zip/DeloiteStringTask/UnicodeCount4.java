package StringTask;

public class UnicodeCount4 {

	public static void main(String[] args) {
		
		{
			String str = "Kaushal Sisat";
			System.out.println("Given String : " + str);
			int c = str.codePointCount(1, 10);
			System.out.println("Codepoint count : " + c);
		}
	}
}

//Given String : Kaushal Sisat
//Codepoint count : 9
