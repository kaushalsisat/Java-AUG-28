package conditionalStatementsHw;
import java.util.Scanner;
// Write a program to input basic salary of an employee and calculate its Gross salary

public class GroosSalary9 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter The Basic Salary :");
		int bs = input.nextInt();
		float hra, da, tot;
		if (bs <= 10000) {
			hra = bs * 0.2f;
			da = bs * 0.8f;
		} else if (bs <= 20000) {
			hra = bs * 0.25f;
			da = bs * 0.9f;
		} else {
			hra = bs * 0.3f;
			da = bs * 0.95f;
		}
		System.out.println("Gross Salary : " + (bs + hra + da));
	}


}

//Enter The Basic Salary :
//46000
//Gross Salary : 103500.0
