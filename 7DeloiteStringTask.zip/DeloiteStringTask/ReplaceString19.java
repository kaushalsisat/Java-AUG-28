package StringTask;

public class ReplaceString19 {

	public static void main(String[] args)
	{
		String str1 = "Kaushal Sisat";		
		String str2 = str1.replace('a', 'Q');
 
		System.out.println("Given String : " + str1);
		System.out.println("After String Character Replace : " + str2);
	}

}

//Given String : Kaushal Sisat
//After String Character Replace : KQushQl SisQt