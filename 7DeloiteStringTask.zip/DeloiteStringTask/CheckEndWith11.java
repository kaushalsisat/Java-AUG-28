package StringTask;

public class CheckEndWith11 {

	public static void main(String[] args) {
		
		 
			String str1 = " Kaushal Sisat";
			String str2 = " Kaushal Sis";
	 
			String end = "at";
			boolean ends1 = str1.endsWith(end);
			boolean ends2 = str2.endsWith(end);
			System.out.println(str1 +"-End String Match: "+ ends1);
			System.out.println(str2 +"-End String Match: "+ ends2);
	}

}
 
