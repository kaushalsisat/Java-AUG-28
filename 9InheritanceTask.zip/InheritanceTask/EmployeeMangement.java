package InheritanceTask;

class Employee{
	
	String name;
	int employeeId;
	double salary;
	
	public Employee(String name, int employeeId, double salary) {
		
		this.name = name;
		this.employeeId = employeeId;
		this.salary = salary;
		this.displayDetails();
	}
	
	public void displayDetails(){
		System.out.println("Name is :"+name);
		System.out.println("Emp Id is :"+employeeId);
		System.out.println("Employee Salary :"+salary);
	}
}

class Manager extends Employee{
	
	String department;
	
	public Manager(String name, int employeeId, double salary, String department) {
		
		super(name, employeeId, salary);
		this.department =department;
		
	   System.out.println("Programing language Skills : "+department);
	}
	
	public void manageTeam() {
		System.out.println("Managing the team.");
		
	}
	
}

class Developer extends Employee{
	
	String programmingLanguage;
	
	public Developer(String name, int employeeId, double salary, String programmingLanguage) {
		
		super(name, employeeId, salary);
		this.programmingLanguage = programmingLanguage;
		
		System.out.println("Programming language skill : " + programmingLanguage);

	}
	
	
	public void writeCode() {
		
		System.out.println("Writing code in java .");
	}
	
}
public class EmployeeMangement {

	public static void main(String[] args) {
		
		Manager mg = new Manager("Kaushal", 45, 50000, "Software Developement ");
		
		        mg.manageTeam();
		        
		  System.out.println("-----------------------------------");
		  
		  Developer dl = new Developer("Rahul", 34, 78000, "Java");
			dl.writeCode();
	}
}
//
//Name is :Kaushal
//Emp Id is :45
//Employee Salary :50000.0
//Programing language Skills : Software Developement 
//Managing the team.
//-----------------------------------
//Name is :Rahul
//Emp Id is :34
//Employee Salary :78000.0
//Programming language skill : Java
//Writing code in java .

