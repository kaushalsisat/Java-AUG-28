package Task1;

import java.util.Scanner;

public class Task7 {
 
	 public static void main(String[] args) {
		   
		 Scanner sc =  new Scanner(System.in);
		    
		 System.out.println("Enter a first Number");
		      int num1 = sc.nextInt();       
		 System.out.println("Enter a Second Number");
		      int num2 =sc.nextInt();
		      
		      int add = num1+num2;
		      int sub = num1-num2;
		      int mul = num1*num2;
		      int div = num1/num2;
		  System.out.println("Sum of Two Number is : " + add);
		  System.out.println("Sbtraction of Two Number is : " + sub); 
		  System.out.println("Multipliction of Two Number is : " + mul);  
		  System.out.println("Division of Two Number is : " + div);  
		 
		 
	}
}
