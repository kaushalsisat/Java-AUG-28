package loopingstatements;

import java.util.Scanner;

//Write a program to find the factorial value of any number

public class Factorial6 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Factorial Number :");
		
		int num = sc.nextInt();
		int fact = 1;
		for(int i=1; i<=num; i++)
		{
			fact *=i;
		}
		System.out.println("Factorial: " + fact);
		
	}

}

//Enter Factorial Number :
//2
//Factorial: 2
