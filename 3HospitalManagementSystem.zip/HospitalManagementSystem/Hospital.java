package HospitalManagementSystem;

public class Hospital {
	
	public static void main(String[] args) {
		System.out.println("Welcome....!");
		Genaral obj=new Genaral();
		obj.List();
		Genaral doc=new Doctor();//polymorprisam
		doc.check();
		doc.details();
	}

}
