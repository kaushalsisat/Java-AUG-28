package JavaTest30;

//16.Write a program to concatenate Two strings
public class Que9 {

	public static void main(String[] args) {
		    
		 String name = "Kushal Sisat";
		 
		 System.out.println(name.concat(" It Is A Computer Science Student"));
	}
	
}
