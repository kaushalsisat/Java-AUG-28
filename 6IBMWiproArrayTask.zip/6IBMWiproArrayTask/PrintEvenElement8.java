package IBMWiproArrayTask;

public class PrintEvenElement8 {

	public static void main(String[] args) {

		// Initialize array
		int[] arr = new int[] { 1, 2, 3, 4, 5 };

		System.out.println("Elements of given array present on even position: ");
 
		for (int i = 1; i < arr.length; i++) {
			
			if(i%2==0)
			System.out.println(i);
		}
	}

}
//Elements of given array present on even position: 
//2
//4