package loopingstatements;

public class AlphabetReverse12 {

	 public static void main(String[] args) {
		
		   char start;
		   
		   for(start ='Z'; start>='A'; start--) {
			   System.out.println(start);
		   }
	}
}

//Z
//Y
//X
//W
//V
//U
//T
//S
//R
//Q
//P
//O
//N
//M
//L
//K
//J
//I
//H
//G
//F
//E
//D
//C
//B
//A
