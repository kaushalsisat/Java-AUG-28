package conditionalStatementsHw;

import java.util.Scanner;

public class ThreeNumberFindMax16 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Number ");
		   int num1 = sc.nextInt();
		System.out.println("Enter Second Number");
		     int num2 = sc.nextInt();
		System.out.println("Enter Third Number");
		     int num3 = sc.nextInt();
		     
		if(num1>num2 && num1>num3) {
			System.out.println("First Number is max");
		}else if(num2>num1 && num2>num3) {
			System.out.println("Second Number is Max");
		}else {
			System.out.println("Third number is max");
		}
	}

//	Enter First Number 
//	10
//	Enter Second Number
//	20
//	Enter Third Number
//	30
//	Third number is max	
	
	
	
}
