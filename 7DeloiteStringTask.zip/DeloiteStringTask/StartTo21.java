package StringTask;

public class StartTo21 {
	public static void main(String[] args)
	{
		String str1 = "Orange is Favorite Fruits";
		String str2 = "Grapes is also my favorite Fruits";
 
		String start = "Orange";
 
		boolean s1 = str1.startsWith(start);
		boolean s2 = str2.startsWith(start);
 
		System.out.println("\""+str1 + "\" starts with \"" +start + "\" ? " + s1);
		System.out.println("\""+str2 + "\" starts with \"" +start + "\" ? " + s2);
	}

}

//"Orange is Favorite Fruits" starts with "Orange" ? true
//"Grapes is also my favorite Fruits" starts with "Orange" ? false