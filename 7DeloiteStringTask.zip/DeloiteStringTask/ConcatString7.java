package StringTask;

public class ConcatString7 {

	public static void main(String[] args) {
		 
		String Str1 = "Kaushal";
		String Str2 = " Sisat";
		
		System.out.println("String 1:"+Str1);
		System.out.println("String 2:"+Str2);
		
		String Con =Str1.concat(Str2);
		
		System.out.println("String One And String Two Concat: "+Con);
	}
}
