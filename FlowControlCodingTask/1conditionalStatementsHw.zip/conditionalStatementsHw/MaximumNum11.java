package conditionalStatementsHw;

import java.util.Scanner;

public class MaximumNum11 {
  
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Number");
		  int num1 = sc.nextInt();
		System.out.println("Enter Second Number");
		  int num2 = sc.nextInt();
	   if(num1>num2) {
		   System.out.println("First Number Is Maximum");
	   }
	   else if(num2>num1) {
		   System.out.println("Second Number Is Maximum"); 
	   }
	   else {
		   System.out.println("Both numbers Are Equals");
	   }
	}
}

//Enter First Number
//20
//Enter Second Number
//20
//Both numbers Are Equals

