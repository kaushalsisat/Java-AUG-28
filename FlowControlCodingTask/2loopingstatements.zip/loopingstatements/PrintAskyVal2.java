package loopingstatements;

//Write a program to print the ASCII values
public class PrintAskyVal2 {
	
	public static void main(String[] args) {
		
		 for(int ASCII =1; ASCII<=255; ASCII++) {
			 
		
			 System.out.println(ASCII);
		 }
	}

}
