package Task1;

public class Task3 {
      
	   public static void main(String[] args) {
		   
		     Double num1 = 2.5;
		     Double num2 = 3.0;
		     Double num3 = 4.5;
		Double  sum = 2.5 + 3.0 + 4.5;
		 int allNu = 3;
		Double  Average = (sum / allNu);
		
	   System.out.println("Average of Some Number is " + Average);
	}
}
//Average of Some Number is 3.3333333333333335