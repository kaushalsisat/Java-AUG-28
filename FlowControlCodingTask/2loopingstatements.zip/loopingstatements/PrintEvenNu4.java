package loopingstatements;
//Write a program to print all even numbers between 1 to 100
import java.util.Scanner;

public class PrintEvenNu4 {
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		      System.out.println("Enter Number Limit :");
		int limit =sc.nextInt();
		for(int num =1; num <=limit; num++) {
			System.out.println(num);
		}
		  
	}

}

//Enter Number Limit :
//10
//1
//2
//3
//4
//5
//6
//7
//8
//9
//10