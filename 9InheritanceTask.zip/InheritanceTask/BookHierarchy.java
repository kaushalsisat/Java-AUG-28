package InheritanceTask;

class Book{
	
	String title;
	String author;
	int year;
	
	public Book(String title, String author, int year) {
		this.title = title;
		this.author = author;
		this.year = year;
		this.displayInfo();
		 
	}
	public void displayInfo() {
		
		System.out.println("Book tittle is : "+year);
		System.out.println("Author name is :"+author);
		System.out.println("Publication Year is :"+year);
		
	}
}

class FictionBook extends Book{
	
	String genre;
	
	public FictionBook(String title, String author, int year, String genre) {
		super(title, author, year);
		this.genre = genre;
	}


	public void read() {
		System.out.println("Enjoy reading this fiction book.");
	}
		
}
class NonFictionBook extends Book{
	    
	  String topic;
	  
	  public NonFictionBook(String title, String author, int year,String topic){
		  
		  super(title,author,year);
		  this.topic = topic;
	  }
	  public void study() {
		  System.out.println("Use this non-fiction book for study ");
	  }
	      
}

public class BookHierarchy {

	public static void main(String[] args) {
		
		   FictionBook fb = new FictionBook("Kaushal Sisat","N.p patil",1995,"Mystery");
		                     fb.read();
		   System.out.println("---------------------------------------------");
		   
		   NonFictionBook nf = new NonFictionBook("Rich dad poor dad","Robert T. Kiyosaki",1997,"Importance of financial literacy");
		           nf.study();
	}
}

//Book tittle is : 1995
//Author name is :N.p patil
//Publication Year is :1995
//Enjoy reading this fiction book.
//---------------------------------------------
//Book tittle is : 1997
//Author name is :Robert T. Kiyosaki
//Publication Year is :1997
//Use this non-fiction book for study 
