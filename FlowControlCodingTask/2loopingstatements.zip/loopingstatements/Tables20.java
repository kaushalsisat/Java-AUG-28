package loopingstatements;

import java.util.Scanner;

//Write a program to print tables

public class Tables20 {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter The Starting Number : ");
		int s = input.nextInt();
		System.out.print("Enter The Ending Number : ");
		int e = input.nextInt();
		System.out.print("Enter The Tables Number : ");
		int t = input.nextInt();
		while (s <= e) {  
			System.out.println(t + " * " + s + " = " + (s * t));
			s++;
		}
	}

}
//Enter The Starting Number : 1
//Enter The Ending Number : 10
//Enter The Tables Number : 5
//5 * 1 = 5
//5 * 2 = 10
//5 * 3 = 15
//5 * 4 = 20
//5 * 5 = 25
//5 * 6 = 30
//5 * 7 = 35
//5 * 8 = 40
//5 * 9 = 45
//5 * 10 = 50