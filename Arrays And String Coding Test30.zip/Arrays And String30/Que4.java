package JavaTest30;

//5. Write a program to array elements to print sum of Negative Numbers
import java.util.Scanner;

public class Que4 {
 
	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 System.out.println("Enetr Limit of Array");
		    int l = sc.nextInt();
		    int []a = new int[l];
		  
		for(int i=0; i<l; i++) {
			System.out.printf("Elements Of Array is : ",i);
		  a[i]=sc.nextInt();
		}
		System.out.println("Convert in Negative Array Element");
	    for(int o:a) {
	    	if(o<0) {
	    		System.out.println("Negative Array Elements is : "+o);
	    	}
	    }
	}
}
