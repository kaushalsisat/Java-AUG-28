package loopingstatements;

import java.util.Scanner;

public class CheckPrimeorNot11 {

	 public static void main(String[] args) {
		   
		   Scanner sc = new Scanner(System.in);
		   System.out.print("Enter the Number :");
			int num = sc.nextInt(); 
			int i, count = 0;
			for(i=2; i<num; i++)
			{
				if(num%i == 0)
				{
					count++;
					break;
				}
			}
			if(count==0)
				System.out.println("This is a Prime Number.");
			else
				System.out.println("This is not a Prime Number.");

	}
}  
//Enter the Number :3
//This is a Prime Number.


