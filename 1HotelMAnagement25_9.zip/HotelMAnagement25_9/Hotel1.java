package HotelMAnagement25_9;

public abstract class Hotel1 {

	   protected String id;
	   protected String name;
	   protected String ContactNo;
	   
	   public Hotel1(String id, String name, String contactNo) {
		     this.id =id;
		     this.name = name;
		     this.ContactNo = contactNo;
	   }
	   
	   abstract void show();
}
