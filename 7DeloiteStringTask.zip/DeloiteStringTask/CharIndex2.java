package StringTask;

public class CharIndex2 {

	public static void main(String[] args)
	{
		String str = "sathya keerthi";
		System.out.println("Given String : " + str);
		int a = str.charAt(0);
		int b = str.charAt(7);
		//Print Charcter Using char
		System.out.println("The Character at Position 0 is " +(char)a);           
		System.out.println("The Character at Position 6 is " +(char)b);
	}

}

// Given String : sathya keerthi
// The Character at Position 0 is s
// The Character at Position 6 is k
