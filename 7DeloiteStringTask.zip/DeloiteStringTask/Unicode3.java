package StringTask;

public class Unicode3 {
	
	public static void main(String[] args)
	{
		String str = "Welcome Java";
		System.out.println("Given String : " + str);
		int v1 = str.codePointAt(0);
		int v2 = str.codePointAt(6);
		
		//Print Character And Asky Value
		System.out.println("Character :"+str.charAt(0)+"\nUnicode Point : " + v1);
		System.out.println("Character :"+str.charAt(6)+"\nUnicode Point : " + v2);
	}


}

//Given String : Welcome Java
//Character :W
//Unicode Point : 87
//Character :e
//Unicode Point : 101