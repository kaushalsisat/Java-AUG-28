package StringTask;

//Write a program to test if a given string contains the specified sequence of char values


public class Contains8 {

	public static void main(String[] args)
	{
		 String str1 = "Kaushal Is The Most Popular Person";
		 String str2 = " Popular ";
		 String str3 = " Populars";
		 System.out.println("Main String One Is: "+str1);
		 System.out.println("String One And String Two Are Same Sequence");
		 System.out.println(str1.contains(str2));
		 System.out.println("String One And String Three Are Same Sequence");
		 System.out.println(str1.contains(str3));

	}

}

//Main String One Is: Kaushal Is The Most Popular Person
//String One And String Two Are Same Sequence
//true
//String One And String Three Are Same Sequence
//false