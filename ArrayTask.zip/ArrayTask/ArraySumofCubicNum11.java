package ArrayTask;


import java.util.Scanner;

//Write a program to array elements to print sum of Cubic Values


public class ArraySumofCubicNum11 {
    
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		  System.out.println("Enter Array Limit");
		   int l =sc.nextInt();
		   int []a = new int[l];
		   int sum =0;
	   for(int i=0; i<l; i++) {	 
		      System.out.println("Element of a :"+i);
		      a[i]=sc.nextInt();
	   }
	   for(int o:a) {
		   
		   sum = sum+(o*o*o);
	   }
		 System.out.println("Sum of Cubic Array Element is"+sum);
	}
}

//Enter Array Limit
//2
//Element of a :0
//2
//Element of a :1
//4
//Sum of Cubic Array Element is72

