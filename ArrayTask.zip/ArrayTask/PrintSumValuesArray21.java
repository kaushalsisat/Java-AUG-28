package ArrayTask;

import java.util.Scanner;

//Write a program to print sum values of an array


public class PrintSumValuesArray21 {

	public static void main(String[] args)
	{      
		int [] a =new int[10]; 
		int sum = 0; 
		for(int i=0;i<10;i++)
		{
			Scanner input =new Scanner(System.in);
			System.out.printf("Element of a[%d] :",i);
			a[i]=input.nextInt();
		}
 
		for (int i : a)
			sum += i;
		System.out.println("Sum Values of Array : " + sum);
	}

}

//Element of a[0] :2
//Element of a[1] :3
//Element of a[2] :4
//Element of a[3] :5
//Element of a[4] :6
//Element of a[5] :7
//Element of a[6] :8
//Element of a[7] :9
//Element of a[8] :9
//Element of a[9] :10
//Sum Values of Array : 63




