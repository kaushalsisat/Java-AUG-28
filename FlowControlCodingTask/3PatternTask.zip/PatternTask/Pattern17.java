package PatternTask;

public class Pattern17 {
	public static void main(String args[])
	{
		int r = 5;
		int t = 1;
		for (int m = 1; m <= r; m++)
		{
			for (int n = 1; n <= m; n++)
			{
				System.out.print(t + " ");
				t++;
			}
			System.out.println();
		}
	}


}

//1 
//2 3 
//4 5 6 
//7 8 9 10 
//11 12 13 14 15 