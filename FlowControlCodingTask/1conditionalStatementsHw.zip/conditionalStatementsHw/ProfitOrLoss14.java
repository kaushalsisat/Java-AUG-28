package conditionalStatementsHw;

import java.util.Scanner;

//Write a program to calculate profit or loss

public class ProfitOrLoss14 {

	public static void main(String[] args) {
		   Scanner sc = new Scanner(System.in);
	System.out.println("Enter The Cost Price :");
		int cp = sc.nextInt();
	System.out.println("Enter The Selling Price :");
	    int sp = sc.nextInt();
	    int p,l;
	  if(sp > cp) { 
		  p = sp - cp;
		  System.out.println("Profit : " + p);
	  }else if(sp < cp) {
		  l = cp - sp;
		  System.out.println("Loss : " + l);
	  }else {
		  System.out.println("No Profit No Loss");
	  }
	  
//	  Enter The Cost Price :
//		  40
//		  Enter The Selling Price :
//		  50
//		  Profit : 10  
	  
	  
	  
	  
	} 
}
