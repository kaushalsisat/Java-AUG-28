package ArrayTask;

import java.util.Scanner;

public class PrintSumOfOddNum14 {
	
     public static void main(String[] args) {
    	 Scanner sc = new Scanner(System.in);
    	 System.out.println("Enter The limit Of Array");
    	     int l = sc.nextInt();
    	      int[]a = new int[l];
    	      int sum = 0;
    	 for(int i=0; i<l; i++) {
    		 System.out.printf("Element of Array is",i);
    		 a[i]=sc.nextInt();
    	 }
      for(int o:a) 
      {
    	  if(o%2==1)
    	  sum = sum + o;
    	
      }
      System.out.println("Sum of Odd Array Element  : " + sum);
	} 
}

//Enter The limit Of Array
//2
//Element of Array is3
//Element of Array is5
//Sum of Odd Array Element  : 8
