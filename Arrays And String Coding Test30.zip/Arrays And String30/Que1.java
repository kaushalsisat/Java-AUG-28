package JavaTest30;

import java.util.Scanner;

//1. Write a program to copy the elements of one array into another array
public class Que1 {

	 public static void main(String[] args) {
		  Scanner sc = new Scanner(System.in);
		  System.out.println("Enter Array Limit");
		      int l = sc.nextInt();
		      int [] a = new int[l];
		      int [] b = new int[l];
		 for(int i=0; i<l; i++) {
			 System.out.println("Array Element is : "+i);
			a[i]=sc.nextInt();
		 }
			for(int i=0;i<l;i++)
			{
				b[i] = a[i];
			}
			System.out.print("orignal Array is");	
			for(int i=0;i<l;i++)
			{
				System.out.printf("\na[%d] = %d",i,a[i]);
			}
			System.out.println(" Copy to new  Array  ");	
			for(int i=0;i<l;i++)
			{
				System.out.printf("\nc[%d] = %d",i,b[i]);
			}
	}
}
