package ArrayTask;

//Write a program to Sort Numeric Array In Ascending Order
import java.util.Arrays;

public class AccendingOrdinArray18 {

	public static void main(String[] args) {
		int[] arr = { 23, 5, 67, 20, 3, 30, 79, 3, 70, 2 };
		System.out.println("Orignal Arrys :" +Arrays.toString(arr));
		Arrays.sort(arr);
		System.out.println("Sorted Array :" + Arrays.toString(arr));

	}
}
//Orignal Arrys :[23, 5, 67, 20, 3, 30, 79, 3, 70, 2]
//Sorted Array :[2, 3, 3, 5, 20, 23, 30, 67, 70, 79]
