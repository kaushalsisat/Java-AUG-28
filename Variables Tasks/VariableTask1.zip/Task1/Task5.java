package Task1;

import java.util.Scanner;

public class Task5 {
	
	public static void main(String[] args) {
		    
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a length");
		  int length  = sc.nextInt();
		System.out.println("Enter a Width");
		  int width  = sc.nextInt();
		  int Area = width * length;
    System.out.println("Area Of Rectangle is : " + Area );
	}

}
//Enter a length
//50
//Enter a Width
//100
//Area Of Rectangle is : 5000