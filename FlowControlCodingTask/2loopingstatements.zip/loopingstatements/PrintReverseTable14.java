package loopingstatements;

import java.util.Scanner;

//Write a program to print reverse tables
public class PrintReverseTable14 {
	
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		System.out.print("Enter The Starting Number : ");
		int s = input.nextInt();
		System.out.print("Enter The Ending Number : ");
		int e = input.nextInt();
		System.out.print("Enter The Tables Number : ");
		int t = input.nextInt();
		while (s >= e) {
			System.out.println(s + " * " + t + " = " + (s * t));
			s--;
		}
	}


}

//Enter The Starting Number : 10
//Enter The Ending Number : 1
//Enter The Tables Number : 2
//10 * 2 = 20
//9 * 2 = 18
//8 * 2 = 16
//7 * 2 = 14
//6 * 2 = 12
//5 * 2 = 10
//4 * 2 = 8
//3 * 2 = 6
//2 * 2 = 4
//1 * 2 = 2
