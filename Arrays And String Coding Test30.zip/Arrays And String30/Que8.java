package JavaTest30;

//13.Write a program to check whether two String objects contain the same data

public class Que8 {
 
	 
	    public static void main(String[] args) {
	        
	        String data1 = "Kaushal is King";
	        String data2 = "kaushal is not king";
	        String data3 = "Kaushal is King";

	        
	        boolean equals1 = data1.equals(data2);
	        
	         
	        boolean equals2 = data1.equals(data3);

	         
	        System.out.println("\"" + data1 + "\" equals \"" +data2 + "\"? " + equals1);
	        System.out.println("\"" + data1 + "\" equals \"" +data3 + "\"? " + equals2);
	    
	}
}
