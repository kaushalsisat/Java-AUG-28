package loopingstatements;

//Write a program to print all natural numbers from 1 to n

import java.util.Scanner;

public class NaturalNum8 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter A Start Number Of a Natural Number");
		  int start = sc.nextInt();
		System.out.print("Enter The Ending Number : ");
		  int end = sc.nextInt();
		  while (start <= end) {
				System.out.println(start);
				start++;
			}

		
	}
}

//Enter A Start Number Of a Natural Number
//1
//Enter The Ending Number : 20
//1
//2
//3
//4
//5
//6
//7
//8
//9
//10
//11
//12
//13
//14
//15
//16
//17
//18
//19
//20
