package ArrayTask;

import java.util.Scanner;
public class ArrayPrintElement22 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		  
		   int[]a=new int[7];
		   
		for(int i=0; i<7; i++) {
			System.out.printf("Element of Array : ");
			a[i]=sc.nextInt();
		}
		System.out.println("Display Array Element");
		for(int e:a) {
			System.out.println(e);
		}
	}
}

//Element of Array : 9
//Element of Array : 8
//Element of Array : 7
//Element of Array : 6
//Element of Array : 5
//Element of Array : 4
//Element of Array : 3
//Display Array Element
//9
//8
//7
//6
//5
//4
//3
