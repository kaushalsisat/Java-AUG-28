package IBMWiproArrayTask;

public class DuplicateArray5 {
	
	public static void main(String[] args) {
		 
		int arr[]= new int[] {1,2,2,3,3,4,5,6};
		  System.out.println("Search Duplicate Array Elements is: ");
		  
        for(int i=0; i<arr.length; i++) {
        	for(int j=i+1; j<arr.length; j++) {
        	 if(arr[i]==arr[j]) 
        		 System.out.println(arr[j]);
        	  }
        	}
        }
        	
	}

//Search Duplicate Array Elements is: 
//2
//3
