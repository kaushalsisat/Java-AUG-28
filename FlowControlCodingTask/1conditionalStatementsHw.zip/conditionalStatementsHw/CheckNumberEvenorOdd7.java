package conditionalStatementsHw;

import java.util.Scanner;
//Check even or odd
public class CheckNumberEvenorOdd7 {

	public static void main(String[] args) {
		  
		Scanner sc = new Scanner (System.in);
		System.out.println("Enter A number");
		
		   int num = sc.nextInt();
		    if (num % 2 == 0) {
		    	System.out.println("It Is Even Number ");
		    }else {
		    	System.out.println("It is odd number");
		    }
		    
		   
	}
}
//Enter A number
//41
//It is odd number
