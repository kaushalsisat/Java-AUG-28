package StringTask;

public class toLowerCase16 {

	public static void main(String[] args) {
		
		 String s1 = "KAUSHAL SISAT";
		 String con =s1.toLowerCase();
		 System.out.println("Fully Convert To Lower Case: " +con);
	}
}

//Fully Convert To Lower Case: kaushal sisat