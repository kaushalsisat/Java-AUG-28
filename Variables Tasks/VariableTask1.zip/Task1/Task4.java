package Task1;

import java.util.Scanner;
public class Task4 {
   
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Sentence");
		String sentence1 = sc.nextLine();
		System.out.println("Enter Second Sentence");
		String sentence2 = sc.nextLine();
		
		System.out.println(sentence1.concat(sentence2));
	}
}

//Enter First Sentence
//My Name is Kaushal
//Enter Second Sentence
//Sisat
//My Name is KaushalSisat