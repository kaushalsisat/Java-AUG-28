package conditionalStatementsHw;

import java.util.Scanner;

public class MonthsInput12 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		   System.out.println("Enter A Month Number");
		 int monthNum = sc.nextInt();
		 
		 if (monthNum == 1)
				System.out.println("This is a January");
			else if (monthNum == 2)
				System.out.println("This is a February");
			else if (monthNum == 3)
				System.out.println("This is a March");
			else if (monthNum == 4)
				System.out.println("This is a April");
			else if (monthNum == 5)
				System.out.println("This is a May");
			else if (monthNum == 6)
				System.out.println("This is a June");
			else if (monthNum == 7)
				System.out.println("This is a July");
			else if (monthNum == 8)
				System.out.println("This is a August");
			else if (monthNum == 9)
				System.out.println("This is a September");
			else if (monthNum == 10)
				System.out.println("This is a October");
			else if (monthNum == 11)
				System.out.println("This is a November");
			else if (monthNum == 12)
				System.out.println("This is a December");
			else
				System.out.println("Enter 1 to 12...");
   
	}
}

//Enter A Month Number
//4
//This is a April

