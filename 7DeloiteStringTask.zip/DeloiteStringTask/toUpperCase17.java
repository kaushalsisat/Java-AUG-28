package StringTask;

public class toUpperCase17 {
	
	public static void main(String[] args) {
		
		 String s1 = "kaushal sisat";
		 String con =s1.toUpperCase();
		 System.out.println("Fully Convert To Upper Case: " +con);
	}

}

//Fully Convert To Upper Case: KAUSHAL SISAT