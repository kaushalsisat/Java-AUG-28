package ArrayTask;

import java.util.Scanner;

public class ArraySumOfPositiveNum15 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter The Limit Of Array is :");
		 int l = sc.nextInt();
		 int []a = new int[l];
		 int sum=0;
		 
		 for(int i=0; i<l; i++) {
			 System.out.printf("Element of Array is :",i);
			 a[i] = sc.nextInt();
		 }
		 for(int o:a) {
			 if(o>0)
		  sum = sum + o;
		 }
		 System.out.println("Addition of Array Element is : " +sum);
	}
}

//Enter The Limit Of Array is :
//2
//Element of Array is :2
//Element of Array is :4
//Addition of Array Element is : 6




