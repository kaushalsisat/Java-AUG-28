package GradeCalculator;

import java.util.Scanner;

public class GradeCalcy {
   
	public static void main(String[] args) {
		
		 Scanner sc = new Scanner(System.in);
		     
		   System.out.println("Enter Student Name");
		      String StdName = sc.nextLine();
		      
		    System.out.println("Enter Student Age");
		       int age = sc.nextInt();
		       
		    System.out.println("Enter Student math Marks");
				 Double Math = sc.nextDouble();
				 
		    System.out.println("Enter Student Science Marks");	 
				 Double Science = sc.nextDouble();
				 
		    System.out.println("Enter Student English Marks");
				 Double English = sc.nextDouble();
				 
			Double Calsum = Math + Science + English;
			Double avgrage = Calsum / 3;
			
			 

			System.out.println("Student Name is "+StdName);
			System.out.println("Student Age is "+age);
			System.out.println("Student Math Mark "+Math);
			System.out.println("Student Science Mark "+Science);
			System.out.println("Student English Mark "+English);
			
			
			System.out.println("Average Of All Subject :"+avgrage);
			
			 
			if( avgrage >=60) {
				System.out.println("Grade Classification is : Grade A");
			}else {
				System.out.println("Grade Classification is : Grade B");
			}
	}
}
