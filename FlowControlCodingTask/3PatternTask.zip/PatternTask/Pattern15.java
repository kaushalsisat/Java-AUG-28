package PatternTask;

public class Pattern15 {

	public static void main(String args[])
	{
		int r = 5;
		for (int m = 1; m <= r; m++) 
                {
                        for (int n = r; n >= m; n--)
			{
				System.out.print(n + " ");
			}
			System.out.println();
		}
	}

}

//5 4 3 2 1 
//5 4 3 2 
//5 4 3 
//5 4 
//5 
