package loopingstatements;

import java.util.Scanner;
//Write a program to print all odd number between 1 to 100


public class oddNumber9 {
	public static void main(String[] args) {
     Scanner sc = new Scanner(System.in);
      System.out.println("Enter The Number Of Limit : ");
       int l = sc.nextInt();
       for(int start=1; start<=l; start++)
       {
    	   if(start %2==1)
    		   System.out.println(start);
       }
	} 
}

//Enter The Number Of Limit : 
//100
//1
//3
//5
//7
//9
//11
//13
//15
//17
//19
//21
//23
//25
//27
//29
//31
//33
//35
//37
//39
//41
//43
//45
//47
//49
//51
//53
//55
//57
//59
//61
//63
//65
//67
//69
//71
//73
//75
//77
//79
//81
//83
//85
//87
//89
//91
//93
//95
//97
//99
