package InheritanceTask;

class Shape{
	
    public void getArea() {
    	
    	System.out.println("Area of shape");
    }
    

	public void getPerimeter() {
    	
    	System.out.println("Perimeter of shape");
    }
	
}

class Circle extends Shape{
	
	double radius;
	
	public Circle(double radius) {
		
		this.radius = radius;
		this.getArea();
		this.getPerimeter();
	}
	
	@Override
	
	 public void getArea() {
	    	
	    	System.out.println("The area of circle is : " + Math.PI*radius);
	    }
	 
	 public void getPerimeter() {
			
			System.out.println("The Perimeter of circle : " + 2*Math.PI*radius);
			
		}
}

class Rectangle extends Shape{
	
	double length;
	double width;
	
	public Rectangle(double length, double width) {
		
		this.length = length;
		this.width = width;
		this.getArea();
		this.getPerimeter();
	}
	
	@Override
	
	public void getArea() {
		
		System.out.println("The area of rectangle is : " + length*width);
	}
	
	public void getPerimeter() {
		
		System.out.println("The Perimeter of rectangle is : " + 2*(length+width));
	}
}



public class ShapeHierarchy {
	public static void main(String[] args) {
		
		Shape Circle = new Circle(6);
		System.out.println("------------------------------------");
		Shape Rectangle = new Rectangle(9,7);
		
	}

}


//The area of circle is : 18.84955592153876
//The Perimeter of circle : 37.69911184307752
//------------------------------------
//The area of rectangle is : 63.0
//The Perimeter of rectangle is : 32.0
