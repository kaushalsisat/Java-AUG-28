package InheritanceTask;

class Account{
	long accountNumber;
	double balance;

	public Account(long accountNumber,double balance) {
		 this.accountNumber = accountNumber;
		 this.balance = balance;
		 this.accountNumberInfo();
	}
	
	public void accountNumberInfo() {
		System.out.println("Account Number is :"+accountNumber);
		System.out.println("Account Balance is :"+balance);

	}
	
	public void deposit(double amount) {
		 
		 System.out.println("Total deposit Amount is"+amount);
	      
		}
	public void withdraw(double amount) {
		 
	    System.out.println("Total withdraw Amount is"+amount);
	     
		}
	
}
class SavingsAccount extends Account{
	double Interest;
	    
	  public SavingsAccount(long accountNumber, double balance,double addInterest) {
		super(accountNumber, balance);
		this.Interest = addInterest;
		 
	}

	public void addInterest() {
		  System.out.println("Balance intress is: "+Interest*balance);
	  }
}
	   
	   	   
class CheckingAccount extends Account{
	
	   int overdraftLimit;
	   
	public CheckingAccount(long accountNumber, double balance, int overdraftLimit) {
	 
		       super(accountNumber,balance);
		       this.overdraftLimit = overdraftLimit;
	}
	
	public void withdraw(double amount) {
		if(amount>overdraftLimit)
		{
			System.out.println("You Have No Sufficiant Balance");
		}
		else {
			System.out.println("The Amount withdraw sucessfully of " +amount);
		}
	}
}

public class BankingSystem {

	  public static void main(String[] args) {
		  
		  //Account ac =new 
		  
		  SavingsAccount sa = new SavingsAccount(1234567890,2300,4.15);
		           sa.deposit(14000);
		          sa.withdraw(4000);
		          sa.addInterest();
		   
		  System.out.println("-------------------------------------");        
		 
		  CheckingAccount ca = new CheckingAccount(1234567890,30000,10000);
		               sa.deposit(1000);
		               ca.withdraw(3000);
	}
}

//Account Number is :1234567890
//Account Balance is :2300.0
//Total deposit Amount is14000.0
//Total withdraw Amount is4000.0
//Balance intress is: 9545.0
//-------------------------------------
//Account Number is :1234567890
//Account Balance is :30000.0
//Total deposit Amount is1000.0
//The Amount withdraw sucessfully of 3000.0
