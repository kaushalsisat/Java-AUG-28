package ArrayTask;

import java.util.Scanner;

public class ArrayOddNum5 {

	public static void main(String []args) {
		Scanner sc = new Scanner(System.in);
			System.out.println("Enter The Limit Of Array");
			  int l = sc.nextInt();
			  int []a = new int[l];
			  
		 for(int i=0; i<l; i++) {
			 System.out.println("all array"+i);
			a[i] = sc.nextInt();
		 }
		 System.out.println("odd element Array");
		 for(int o:a) {
			 if(o%2==1)
				 System.out.println(o);
		 }
	}
}

//Enter The Limit Of Array
//4
//all array0
//2
//all array1
//3
//all array2
//4
//all array3
//5
//odd element Array
//3
//5
