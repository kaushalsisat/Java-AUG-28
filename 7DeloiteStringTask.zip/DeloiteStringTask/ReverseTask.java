package StringTask;

public class ReverseTask {

	 public static void main(String[] args) {
		
		   String name = "Kaushal";
		   String revName= " ";
		   
		   System.out.println("Orignal String: "+name);
		     
		   for(int i=0; i<name.length(); i++) {
			   revName = name.charAt(i)+revName;
		   }
		 System.out.println("Name Reverse :"+revName);
	}
}

// Orignal String: Kaushal
// Name Reverse :lahsuaK 