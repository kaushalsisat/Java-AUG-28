package PatternTask;

public class Pattern8 {
	
	public static void main(String args[])
	{
		int r = 5;
		for (int m = r; m >= 1; m--)
		{
			for (int n = 1; n < m; n++)
			{
				System.out.print(" ");
			}
			for (int p = m; p <= r; p++)
			{
				System.out.print(p + " ");
			}
			System.out.println();
		}
	}
}

//    5 
//   4 5 
//  3 4 5 
// 2 3 4 5 
//1 2 3 4 5 



