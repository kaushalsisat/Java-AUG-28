package ArrayTask;

import java.util.Arrays;
import java.util.Collections;


public class ArrayDesendingOrder32 {

	public static void main(String[] args) {
		Integer[] arr = { 23, 5, 67, 20, 3, 30, 79, 3, 70, 2 };
		System.out.println("Original Array : " + Arrays.toString(arr));
		Arrays.sort(arr, Collections.reverseOrder());
		System.out.println("Sorted Array : " + Arrays.toString(arr));
		
	}

}

//Original Array : [23, 5, 67, 20, 3, 30, 79, 3, 70, 2]
//Sorted Array : [79, 70, 67, 30, 23, 20, 5, 3, 3, 2]
